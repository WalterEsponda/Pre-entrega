# web-layout
Repositorio de ejemplos para visualizar interactivamente los temas dados en el curso de Desarrollo (maquetación) Web.

## Authors

- [@chamanDEV](https://www.github.com/saulkrujoski)

## Demos incluidas

### Box model

Demo para probar interactivamente algunas de las propiedades que hacen al concepto de modelado de caja.

### Overflow

Demo para probar las propiedades de overflow.

### Display

Demo para probar las propiedades de display.

### Position

Demo para probar las propiedades de position.

### z-index

Demo para probar las propiedades de z-index.

### Flexbox

Demo para probar las propiedades del modelo de caja.

### Grid System

Demo para probar las propiedades del modelo de grilla.