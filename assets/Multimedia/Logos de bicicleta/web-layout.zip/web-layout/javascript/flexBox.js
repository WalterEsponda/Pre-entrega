// Valores establecidos
const CHILD_COUNT = 9;
const ORDER_DEFAULT = 1;

const changeOrderValue = (id = "", value = ORDER_DEFAULT) => {
  let identifier = id.split("-").pop();
  document.getElementById("child-box-".concat(identifier)).style.order =
    parseInt(value);
};

const changePropertyValue = (property = "a-b", value = "value") => {
  let key = property.split("-");
  key[1] = key[1].charAt(0).toUpperCase() + key[1].slice(1);
  key = key.join("");
  document.getElementById("flexBoxContent").style[key] = value;
};

const initialize = () => {
  for (let index = 1; index <= CHILD_COUNT; index++) {
    document.getElementById("child-order-".concat(index.toString())).value =
      ORDER_DEFAULT;
    document.getElementById("child-box-".concat(index.toString())).style.order =
      ORDER_DEFAULT;
  }
};

initialize();
