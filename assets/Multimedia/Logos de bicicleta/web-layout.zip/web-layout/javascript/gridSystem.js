const changePropertyValue = (property = "a-b", value = "value", sufix = "") => {
  let key = property.split("-");
  for (let index = 1; index < key.length; index++) {
    key[index] = key[index].charAt(0).toUpperCase() + key[index].slice(1);
  }
  key = key.join("");
  document.getElementById("gridContent").style[key] = value + sufix;
};

const changeTemplateValue = (property = "a-b", value = 1) => {
  let key = property.split("-");
  for (let index = 1; index < key.length; index++) {
    key[index] = key[index].charAt(0).toUpperCase() + key[index].slice(1);
  }
  key = key.join("");
  let newValue = "";
  let percent = parseInt(100 / value) - (value < 7 ? 5 : 3);
  for (let index = value; index > 0; index--) {
    newValue = newValue + " " + percent.toString() + "%";
  }
  newValue.trim();
  document.getElementById("gridContent").style[key] = newValue;
};
