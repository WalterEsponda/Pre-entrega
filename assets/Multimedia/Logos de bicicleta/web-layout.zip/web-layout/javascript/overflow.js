// Valores establecidos
let overflow = OVERFLOW_DEFAULT;

const performAction = () => {
  let element = document.getElementById("overflowContent");
  element.style.overflow = overflow;
};

const changeOverflowValue = (value = OVERFLOW_DEFAULT) => {
  overflow = value;
  performAction();
};

const initialize = () => {
  // Overflow
  let radios = document.getElementsByName("overflow");
  radios.forEach((r) => {
    if (r.id.toLowerCase().includes(overflow.toLowerCase())) {
      r.checked = true;
    }
  });

  // Accionar configuración de parámetros para componentes padre e hijo.
  performAction();
};

initialize();
