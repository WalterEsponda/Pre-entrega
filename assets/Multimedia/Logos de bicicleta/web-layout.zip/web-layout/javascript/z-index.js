// Valores establecidos
let boxesDepth = BOXES_DEPTH_DEFAULT;
const MIN_INDEX = BOXES_DEPTH_DEFAULT[0];
const MAX_INDEX = BOXES_DEPTH_DEFAULT[BOXES_DEPTH_DEFAULT.length - 1];

const switchDephValue = () => {
  for (let index = 0; index < boxesDepth.length; index++) {
    boxesDepth[index] =
      boxesDepth[index] + 1 <= MAX_INDEX ? boxesDepth[index] + 1 : MIN_INDEX;
  }
  initialize();
};

const initialize = () => {
  for (let index = 0; index < boxesDepth.length; index++) {
    document.getElementById("box-".concat(index + 1)).style.zIndex =
      boxesDepth[index];
  }
};

initialize();
