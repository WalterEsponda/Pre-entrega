// Valores establecidos
let display = null;

const performAction = () => {
  if (display && display !== "none") {
    let element = document.getElementById("displayContent");
    for (let index = 0; index < element.children.length; index++) {
      element.children[index].style.display = display;
    }
  } else if (display === "none") {
    let element = document.querySelector("#displayContent em");
    element.style.display = display;
  }
};

const resetAll = () => {
  let element = document.getElementById("displayContent");
  element.childNodes.forEach((child) => {
    switch (child.tagName) {
      case "P":
        child.style.display = "block";
        break;
      case "EM":
      case "SPAN":
        child.style.display = "inline";
        break;
    }
  });
  document.getElementById("displayNone").checked = false;
};

const changeDisplayValue = (value = OVERFLOW_DEFAULT) => {
  display = value;
  performAction();
};
