// Valores establecidos
let position = POSITION_DEFAULT;

const performAction = () => {
  if (position && position !== POSITION_DEFAULT) {
    let element = document.getElementById("box-2");
    element.style.position = position;
  }
};

const resetPositionAll = () => {
  let element = document.getElementById("box-2");
  element.style.position = POSITION_DEFAULT;
  let radios = document.getElementsByName("position");
  for (let index = 0; index < radios.length; index++) {
    radios[index].checked = null;
  }
};

const changePositionValue = (value = POSITION_DEFAULT) => {
  position = value;
  performAction();
};
