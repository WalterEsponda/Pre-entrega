// Valores establecidos
let customSides = SIDES_DEFAULT;
let contentBoxSizing = BOX_SIZING_DEFAULT;

let selectedMarginSides = new Sides(
  customSides.top,
  customSides.right,
  customSides.bottom,
  customSides.left
);

let selectedPaddingSides = new Sides(
  customSides.top,
  customSides.right,
  customSides.bottom,
  customSides.left
);

let selectedBorderWidthSides = new Sides(
  customSides.top,
  customSides.right,
  customSides.bottom,
  customSides.left
);

let selectedSides = {
  padding: selectedPaddingSides,
  margin: selectedMarginSides,
  borderWidth: selectedBorderWidthSides,
};

const SIDE_PARAMS = ["padding", "margin", "borderWidth"];

let params = {
  paddingRange: PADDING_DEFAULT,
  marginRange: MARGIN_DEFAULT,
  borderWidthRange: BORDER_WIDTH,
  borderRadiusRange: BORDER_RADIUS,
  widthRange: WIDTH_DEFAULT,
  heigthRange: HEIGHT_DEFAULT,
};

// Componentes de control
const components = {
  paddingRange: document.getElementById("paddingRange"),
  marginRange: document.getElementById("marginRange"),
  borderWidthRange: document.getElementById("borderWidthRange"),
  borderRadiusRange: document.getElementById("borderRadiusRange"),
  widthRange: document.getElementById("widthRange"),
  heigthRange: document.getElementById("heigthRange"),
};

let entities = {
  dad: document.getElementById("dad"),
  child: document.getElementById("child"),
};

const performAction = () => {
  const valueParams = {
    padding: params["paddingRange"].toString().concat("px"),
    margin: params["marginRange"].toString().concat("px"),
    borderRadius: params["borderRadiusRange"].toString().concat("px"),
    borderWidth: params["borderWidthRange"].toString().concat("px"),
  };
  const DEFAULT_VALUE = "0px";

  entities.child.style.boxSizing = contentBoxSizing;
  entities.child.style.height = params["heigthRange"].toString().concat("%");
  entities.child.style.width = params["widthRange"].toString().concat("%");

  // Generales
  SIDE_PARAMS.forEach((property) => {
    for (const [key, value] of Object.entries(selectedSides[property])) {
      let definitiveValue = value ? valueParams[property] : DEFAULT_VALUE;
      let definitiveProperty = property.concat(
        key.charAt(0).toUpperCase() + key.slice(1)
      );

      if (property == "borderWidth") {
        definitiveProperty =
          "border" + key.charAt(0).toUpperCase() + key.slice(1) + "Width";
      }

      entities.child.style[definitiveProperty] = definitiveValue;
    }
  });
  entities.child.style.borderRadius = valueParams.borderRadius;
};

// Cambiar cómo calculamos el tamaño
const toggleBoxSizingValue = (selected) => {
  contentBoxSizing = selected;
  let id =
    contentBoxSizing == BOX_SIZING_DEFAULT
      ? "radioBoxSizingContent"
      : "radioBoxSizingBorder";
  let component = document.getElementById(id);
  component.setAttribute("checked", true);
  performAction();
};

const changeValue = (key, value) => {
  params[key] = value;
  performAction();
};

const changeSideValue = (key = "", value = true) => {
  const selected = SIDE_PARAMS.find((label) =>
    key.toLowerCase().includes(label.toLowerCase())
  );
  for (const [sideKey, sideValue] of Object.entries(selectedSides[selected])) {
    if (key.toLowerCase().includes(sideKey.toLowerCase())) {
      selectedSides[selected][sideKey] = value;
    }
  }
  performAction();
};

const initialize = () => {
  // reflejar en la UI los parámetros por default
  toggleBoxSizingValue(contentBoxSizing);

  // Rangos
  components["paddingRange"].value = params["paddingRange"];
  components["marginRange"].value = params["marginRange"];
  components["borderWidthRange"].value = params["borderWidthRange"];
  components["borderRadiusRange"].value = params["borderRadiusRange"];
  components["widthRange"].value = params["widthRange"];
  components["heigthRange"].value = params["heigthRange"];

  // Checkboxes
  SIDE_PARAMS.forEach((property) => {
    for (const [side, value] of Object.entries(selectedSides[property])) {
      let definitiveProperty = property.concat(
        side.charAt(0).toUpperCase() + side.slice(1)
      );
      document.getElementById(definitiveProperty).checked = value;
    }
  });

  // Accionar configuración de parámetros para componentes padre e hijo.
  performAction();
};

initialize();
