class Sides {
  left = true;
  right = true;
  top = true;
  bottom = true;

  constructor(top = true, right = true, bottom = true, left = true) {
    this.top = top;
    this.right = right;
    this.bottom = bottom;
    this.left = left;
  }
}
