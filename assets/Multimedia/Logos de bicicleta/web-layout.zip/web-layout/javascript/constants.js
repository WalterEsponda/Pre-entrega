const SIDES_DEFAULT = {
  top: true,
  left: true,
  right: true,
  bottom: true,
};

const BOX_SIZING_DEFAULT = "content-box";

const PADDING_DEFAULT = 10;

const MARGIN_DEFAULT = 10;

const HEIGHT_DEFAULT = 50;

const WIDTH_DEFAULT = 60;

const BORDER_RADIUS = 10;

const BORDER_WIDTH = 1;

const OVERFLOW_DEFAULT = "visible";

const POSITION_DEFAULT = "static";

const BOXES_DEPTH_DEFAULT = [2, 3, 4];
